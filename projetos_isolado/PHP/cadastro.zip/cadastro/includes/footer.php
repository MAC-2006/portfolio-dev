<footer class="text-center mt-4">
        <p>&copy; <?php echo date("Y"); ?> Sistema de Usuários. Todos os direitos reservados.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
